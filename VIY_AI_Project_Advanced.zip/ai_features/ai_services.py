from flask import Flask, request, jsonify
import openai

app = Flask(__name__)

openai.api_key = "your_openai_api_key_here"

@app.route('/voice', methods=['POST'])
def voice_to_text():
    data = request.json
    audio_url = data.get("audioUrl", "")

    response = openai.Audio.transcriptions.create(
        file=audio_url,
        model="whisper-1"
    )
    
    return jsonify({"text": response["text"]})

@app.route('/generate-image', methods=['POST'])
def generate_image():
    data = request.json
    prompt = data.get("prompt", "")

    response = openai.Image.create(
        model="dall-e-2",
        prompt=prompt,
        n=1,
        size="1024x1024"
    )
    
    return jsonify({"imageUrl": response["data"][0]["url"]})

if __name__ == '__main__':
    app.run(debug=True)
