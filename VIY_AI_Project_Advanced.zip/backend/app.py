from flask import Flask, request, jsonify
import openai

app = Flask(__name__)

# Set your OpenAI API Key here
openai.api_key = "your_openai_api_key_here"

@app.route('/chat', methods=['POST'])
def chat():
    data = request.json
    user_message = data.get("message", "")

    if not user_message:
        return jsonify({"error": "Message is required"}), 400

    # Generate AI response
    response = openai.ChatCompletion.create(
        model="gpt-4",
        messages=[{"role": "user", "content": user_message}]
    )
    
    ai_message = response["choices"][0]["message"]["content"]
    
    return jsonify({"response": ai_message})

if __name__ == '__main__':
    app.run(debug=True)
